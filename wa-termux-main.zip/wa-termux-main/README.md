
### Alat dan Bahan
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan kode qr kak)
> jaringan internet kenceng,kuota+
> penyimpanan yang memadai
> aplikasi whatsapp
> aplikasi termux
> kopi+rokok ;v
```

### Informasi Pengguna
Script ini di modifikasi sama saya sendiri XP-TN
```bash
> Support My Github😘
> Jangan Lupa follow github saya🤗
> jika error lapor ke Pembuat script chat wa link ada di github 
```
### Cara Installnya
Script ini di modifikasi sama saya sendiri.
```bash
kalo lu belum punya apk termux, download di playstore
> buka termux
> pkg upgrade
> pkg update
> pkg install git
> pkg install tesseract
> pkg install unzip
> git clone https://github.com/130N-STUDIO/wa-termux
> ls
> Termux-setup-storage
> ls
> cd
> ls
> unzip wa-termux
> cd wa-termux
> pkg install ffmpeg
> pkg install wget
> pkg install nodejs
> pkg install npm
> npm i -g cwebp
> npm i node-tesseract-ocr
> npm i -g ytdl
> npm i
> npm i got
> node index.js

—> ENJOY DAN SCAN QR NYA
```
